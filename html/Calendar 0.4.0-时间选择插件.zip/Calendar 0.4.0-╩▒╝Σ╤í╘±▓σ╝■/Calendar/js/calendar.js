﻿//2014.10.18 0.4.0
var Calendar = function (Options) {
    var obj = this;
    var root = this.root = document.createElement("div");
    root.className = "CaleRoot";
    document.body.appendChild(root);

    var outputObj = this.outputObj;
    var options = this.options = {
        global: {
            root: null,
            autoHide: true,
            size: {
                width: 200,
                height: "auto"
            },
            unit: {
                year: "年",
                month: "月",
                day: "日"
            },
            outputUnit: {
                year: "年",
                month: "月",
                day: "日",
                suffix: ""
            },
            weekday: {
                title: ["一", "二", "三", "四", "五", "六", "日"],
                start: 6
            },
            month: ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二"],
            range: {
                length: 1,
                connect: "-"
            },
            dateDefault: false,
            location: {
                follow: true,
                index: 0
            }
        },
        head: {
            PN: {
                size: {
                    width: 20,
                    height: 20
                }
            },
            height: 20
        },

        body: {
            height: 145
        },
        event: {
            day: {
                clicked: function (dayCell) { },
                running: function (dayCell) { }
            },
            month: {
                next: function (caleId) { },
                prev: function (caleId) { },
                clicked: function (caleId) { },
                selected: function (panCell) { }
            },
            year: {
                next: function (caleId) { },
                prev: function (caleId) { },
                clicked: function (caleId) { },
                selected: function (panCell) { }
            },
            page: {
                next: function (caleId) { },
                prev: function (caleId) { }
            },
            output: function () { }
        }
    }
    $().updateObject(options, Options);
    var now = new Date();
    var yearNow = now.getFullYear();
    var yearOutput = [], yearInput = [], yearDefault = [];

    var monthNow = now.getMonth() + 1;
    var monthOutput = [], monthInput = [], monthDefault = [];
    var monthMax = [31, 0, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    var dayNow = now.getDate();
    var dayOutput = [], dayInput = [], dayDefault = [];
    var dayCurrPage = [];

    var arrPage = [];
    var arrCale = [];
    var arrPan = [];

    var trigger;
    this.calendar = [];







    var CreateFrame = function () {

        yearDefault.push(yearNow);
        monthDefault.push(monthNow);
        dayDefault.push(dayNow);

        var dayLengthLastMonth = 0, dayLengthNextMonth = 0;

        var caleContainer = document.createElement("div");
        caleContainer.className = "caleContainer";
        caleContainer.caleId = arrCale.length;
        arrCale.push(caleContainer);
        arrPage[caleContainer.caleId] = [];
        if (yearInput.length != options.global.range.length) {
            yearInput.push(yearDefault[caleContainer.caleId]);
            monthInput.push(monthDefault[caleContainer.caleId]);
            dayInput.push(dayDefault[caleContainer.caleId]);
        }


        var yearChanging = yearInput[caleContainer.caleId];
        var monthChanging = monthInput[caleContainer.caleId];

        var headContainer = document.createElement("div");
        headContainer.className = "headContainer";
        caleContainer.appendChild(headContainer);

        var yearHeadBtn = document.createElement("span");
        yearHeadBtn.className = "yearHeadBtn";
        var monthHeadBtn = document.createElement("span");
        monthHeadBtn.className = "monthHeadBtn";

        var bodyContainer = document.createElement("div");
        bodyContainer.className = "bodyContainer";
        bodyContainer.style.overflow = "hidden";
        bodyContainer.style.width = options.global.size.width + "px";
        caleContainer.appendChild(bodyContainer);

        var weekdayContainer = document.createElement("div");
        weekdayContainer.className = "weekdayContainer";
        bodyContainer.appendChild(weekdayContainer);

        var pageContainer = document.createElement("div");
        pageContainer.className = "pageContainer";
        pageContainer.style.position = "relative";
        var pageOuter = document.createElement('table');
        pageOuter.className = "pageOuter";
        var pageOuterTr = document.createElement("tr");
        pageOuter.appendChild(pageOuterTr);
        pageContainer.appendChild(pageOuter)
        bodyContainer.appendChild(pageContainer);

        var footContainer = document.createElement("div");
        footContainer.className = "footContainer";
        caleContainer.appendChild(footContainer);



        var NextPage = function () {
            if (arrPage[caleContainer.caleId].length > 1) return false;
            if (++monthChanging == 13) {
                yearChanging++;
                monthChanging = 1;
            }
            SetHeadBtnValue();
            pageContainer.style.width = (2 * options.global.size.width) + "px";
            var nextPage = CreatePage(yearChanging, monthChanging);
            pageOuterTr.appendChild(nextPage);
            options.event.page.next(caleContainer.caleId);
            $(pageContainer).animate({ left: -options.global.size.width }, 200, 0, 0, function (me) {
                pageOuterTr.removeChild(arrPage[caleContainer.caleId].shift())
                pageContainer.style.width = options.global.size.width + "px";
                pageContainer.style.left = "0px";
            });
        }

        var PrevPage = function () {
            if (arrPage[caleContainer.caleId].length > 1) return false;
            if (--monthChanging == 0) {
                yearChanging--;
                monthChanging = 12;
            }
            SetHeadBtnValue();
            pageContainer.style.width = (2 * options.global.size.width) + "px";
            var prevPage = CreatePage(yearChanging, monthChanging);
            pageOuterTr.insertBefore(prevPage, arrPage[caleContainer.caleId][0]);
            pageContainer.style.left = -options.global.size.width + "px";
            options.event.page.prev(caleContainer.caleId);
            $(pageContainer).animate({ left: 0 }, 200, 0, 0, function (me) {
                pageOuterTr.removeChild(arrPage[caleContainer.caleId].shift())
                pageContainer.style.width = options.global.size.width + "px";
            });
        }

        var CreateHead = function () {
            var prev = document.createElement("div");
            prev.className = "calePrev";
            prev.style.width = options.head.PN.size.width + "px";
            prev.style.height = options.head.PN.size.height + "px";
            $(prev).addEvent('click', function () { EventPrevClcik() });

            var head = document.createElement("div");
            head.className = "caleHead";
            head.style.width = options.global.size.width - 2 * parseInt(prev.style.width) + "px";
            yearHeadBtn.innerHTML = yearInput[caleContainer.caleId] + options.global.unit.year;
            head.appendChild(yearHeadBtn);
            monthHeadBtn.innerHTML = monthInput[caleContainer.caleId] + options.global.unit.month;
            head.appendChild(monthHeadBtn);


            var next = document.createElement("div");
            next.className = "caleNext";
            next.style.width = options.head.PN.size.width + "px";
            next.style.height = options.head.PN.size.height + "px";
            $(next).addEvent('click', function () { EventNextClick() });

            headContainer.appendChild(prev);
            headContainer.appendChild(head);
            headContainer.appendChild(next);
        }
        var CreateWeekday = function () {
            var weekday = document.createElement("table");
            var index;
            weekday.style.width = options.global.size.width + "px";
            var tr = document.createElement("tr");
            for (var i = 0; i < 7; i++) {
                var td = document.createElement("td");
                td.className = "weekday";
                index = (options.global.weekday.start + i) % 7;
                if (index >= 5) {
                    td.className += " weekend";
                }
                td.innerHTML = options.global.weekday.title[index];
                tr.appendChild(td);
            }
            weekday.appendChild(tr);
            return weekday;
        }

        var CreatePage = function (year, month, returnOutputDay) {
            var caleId = caleContainer.caleId;
            dayCurrPage[caleId] = [];
            var monthFirstDay = new Date(year, month - 1, 1).getDay();
            var offsetFirstDay = (monthFirstDay - options.global.weekday.start + 6) % 7 || 7;
            var monthLength = getMonthLength(year, month);

            var pageOuterTd = document.createElement("td");

            var page = document.createElement('table');
            page.style.width = options.global.size.width + "px";
            //page.style.height = bodyContainer.offsetHeight + "px";
            var dayCount = 0;
            for (var i = 0; i < 6; i++) {
                var tr = document.createElement("tr");
                for (var j = 0; j < 7; j++) {
                    var td = document.createElement("td");
                    dayCurrPage[caleId].push(td);
                    tr.appendChild(td);
                }
                page.appendChild(tr);
            }


            var yearPrev = year, monthPrev = month - 1;
            var yearNext = year, monthNext = month + 1;
            var monthPrevLength;
            if (month == 1) {
                yearPrev--;
                monthPrevLength = 31;
                monthPrev = 12;
            }
            else {
                monthPrevLength = getMonthLength(yearPrev, monthPrev);
            }
            if (month == 12) {
                yearNext++;
                monthNext = 1;
            }

            //生成日期单元格
            var dayCurrPos = 0;
            for (var i = 0; i < offsetFirstDay; i++) {
                var dayCell = dayCurrPage[caleId][dayCurrPos];
                dayCell.caleId = caleId;
                dayCell.year = yearPrev;
                dayCell.month = monthPrev;
                dayCell.day = monthPrevLength - offsetFirstDay + i + 1;
                dayCell.innerHTML = dayCell.day;
                dayCell.className = "day dayPrevMonth";
                dayCell.index = dayCurrPos;
                dayCell.cssSuffix = " dayPrevMonth";
                dayCurrPos++;
                options.event.day.running(dayCell);
            }
            dayLengthLastMonth = dayCurrPos;
            for (var i = 1; i <= monthLength; i++) {
                var dayCell = dayCurrPage[caleId][dayCurrPos];
                dayCell.caleId = caleId;
                dayCell.year = year;
                dayCell.month = month;
                dayCell.day = i;
                dayCell.innerHTML = i;
                dayCell.className = "day dayCurrMonth";
                dayCell.index = dayCurrPos;
                dayCell.cssSuffix = " dayCurrMonth";
                dayCurrPos++;
                options.event.day.running(dayCell);
            }
            if (dayInput[caleId]) {
                dayOutput[caleId] = dayCurrPage[caleId][dayInput[caleId] + dayLengthLastMonth - 1];

                dayInput[caleId] = null
            }
            var i = 1;
            for (dayCurrPos; dayCurrPos < dayCurrPage[caleId].length; dayCurrPos++) {
                var dayCell = dayCurrPage[caleId][dayCurrPos];
                dayCell.caleId = caleId;
                dayCell.year = yearNext;
                dayCell.month = monthNext;
                dayCell.index = dayCurrPos;
                dayCell.day = i++;
                dayCell.innerHTML = dayCell.day;
                dayCell.className = "day dayNextMonth";
                dayCell.cssSuffix = " dayNextMonth";
                options.event.day.running(dayCell);
            }
            var dayLengthNextMonth = i--;
            //生成日期单元格

            //日期单元格绑定事件
            $(dayCurrPage[caleId]).addEvent('click', function (me) {
                if (dayOutput[caleId]) {
                    dayOutput[caleId].className = "day"
                    dayOutput[caleId].className += dayOutput[caleId].cssSuffix;
                }
                monthOutput[caleId] = monthChanging;
                yearOutput[caleId] = yearChanging;
                dayOutput[caleId] = me;
                caleContainer.selected = true;
                Output(caleId);
                me.className = "day daySelected";
                options.event.day.clicked(me);
            });
            //日期单元格绑定事件


            //日期单元格上色
            //周末
            var j = 6 - monthFirstDay;
            for (var i = offsetFirstDay + j; i < offsetFirstDay + monthLength; i++) {
                dayCurrPage[caleId][i].className += " dayWeekend";
                dayCurrPage[caleId][i].cssSuffix = " dayWeekend";
                if (i + 1 < offsetFirstDay + monthLength) {
                    dayCurrPage[caleId][i + 1].className += " dayWeekend";
                    dayCurrPage[caleId][i].cssSuffix = " dayWeekend";
                    i += 6;
                }
            }
            //选中天
            if (dayOutput[caleId]) {
                var day = dayOutput[caleId];
                if (monthChanging == day.month && yearChanging == day.year) {
                    dayOutput[caleId] = dayCurrPage[caleId][dayLengthLastMonth - 1 + day.day];
                }
                else if (monthPrev == day.month && yearPrev == day.year) {
                    var diff = dayCurrPage[caleId][dayLengthLastMonth - 1].day - day.day;
                    if (diff <= dayLengthLastMonth) {
                        dayOutput[caleId] = dayCurrPage[caleId][dayLengthLastMonth - diff - 1];
                    }
                }
                else if (monthNext == day.month && yearNext == day.year) {

                    var diff = dayCurrPage[caleId][41].day - day.day;
                    if (diff <= dayLengthNextMonth && diff >= 0) {
                        dayOutput[caleId] = dayCurrPage[caleId][41 - diff];
                    }
                }
                dayOutput[caleId].className = "day daySelected";
            }
            //今天
            if (monthChanging == monthNow && yearChanging == yearNow) {
                dayCurrPage[caleId][dayNow + dayLengthLastMonth - 1].className = "day dayNow";
                dayCurrPage[caleId][dayNow + dayLengthLastMonth - 1].cssSuffix = " dayNow";
            }
            //日期单元格上色


            pageOuterTd.appendChild(page);
            arrPage[caleId].push(pageOuterTd);

            return pageOuterTd;
        }; //CreatePage

        var CreateFoot = function () {

        }


        var panCellWidth = options.global.size.width / 4;
        var panCellHeight = 40;
        var panCellArr;
        var panOuter;
        var arrPan = [];



        //panContainer
        var panYearStartYear = yearNow - 4;
        var panContainer = document.createElement("div");
        bodyContainer.appendChild(panContainer);
        var panOuterTable = document.createElement('table');
        var panOuterTableTr = document.createElement('tr');
        panOuterTable.appendChild(panOuterTableTr);
        panContainer.appendChild(panOuterTable);
        var IniPanContainer = function () {
            panContainer.style.backgroundColor = "#fff";
            panContainer.style.position = "relative";
            panContainer.style.left = "0px";
            panContainer.style.overflow = "hidden";
            panContainer.style.width = options.global.size.width + "px";
            panContainer.style.top = -bodyContainer.offsetHeight + "px";
            panContainer.style.height = "0px";
            $(yearHeadBtn).addEvent('click', EventYearHeadClick)
            $(monthHeadBtn).addEvent('click', EventMonthHeadClick)
        }
        var CreatePanYear = function (year) {
            panCellArr = [];
            var panOuterTableTd = document.createElement('td');
            var panInnerTable = document.createElement('table');
            yearHeadBtn.innerHTML = year + "-" + (year + 11);
            for (var i = 0; i < 3; i++) {
                var panInnerTableTr = document.createElement('tr');
                for (var j = 0; j < 4; j++) {
                    var panInnerTableTd = document.createElement('td');
                    panInnerTableTd.innerHTML = year++;
                    panInnerTableTd.className = "panCell";
                    panInnerTableTd.style.width = panCellWidth + "px";
                    panInnerTableTd.style.height = panCellHeight + "px";
                    panInnerTableTd.caleId = caleContainer.caleId;
                    panInnerTableTr.appendChild(panInnerTableTd);
                    panCellArr.push(panInnerTableTd);
                }
                panInnerTable.appendChild(panInnerTableTr);
            }
            panOuterTableTd.appendChild(panInnerTable);
            arrPan.push(panOuterTableTd)
            $(panCellArr).addEvent('click', function (me) {
                yearChanging = me.innerHTML;
                pageOuterTr.removeChild(arrPage[me.caleId].pop());
                CreatePage(yearChanging, monthChanging);
                pageOuterTr.appendChild(arrPage[me.caleId][0]);
                ClosePanContainer();
                options.event.year.selected(me);
            })
            options.event.year.clicked(caleContainer.caleId);
            return panOuterTableTd;
        }
        var CreatePanMonth = function () {
            panCellArr = [];
            var m = 0
            var panOuterTableTd = document.createElement('td');
            var panInnerTable = document.createElement('table');
            monthHeadBtn.innerHTML = yearChanging + options.global.unit.year;
            for (var i = 0; i < 3; i++) {
                var panInnerTableTr = document.createElement('tr');
                for (var j = 0; j < 4; j++) {
                    var panInnerTableTd = document.createElement('td');
                    panInnerTableTd.innerHTML = options.global.month[m++] + options.global.unit.month;
                    panInnerTableTd.className = "panCell";
                    panInnerTableTd.style.width = panCellWidth + "px";
                    panInnerTableTd.style.height = panCellHeight + "px";
                    panInnerTableTd.caleId = caleContainer.caleId;
                    panInnerTableTr.appendChild(panInnerTableTd);
                    panCellArr.push(panInnerTableTd);
                }
                panInnerTable.appendChild(panInnerTableTr);
            }
            panOuterTableTd.appendChild(panInnerTable);
            arrPan.push(panOuterTableTd)
            $(panCellArr).addEvent('click', function (me, i) {
                monthChanging = i + 1;
                pageOuterTr.removeChild(arrPage[me.caleId].pop());
                CreatePage(yearChanging, monthChanging);
                pageOuterTr.appendChild(arrPage[me.caleId][0]);
                ClosePanContainer();
                options.event.month.selected(me);
            })
            panCellArr[monthChanging - 1].className = "panCellCurr";
            options.event.month.clicked(caleContainer.caleId);
            return panOuterTableTd;
        }
        var ClosePanContainer = function () {
            EventNextClick = NextPage;
            EventPrevClcik = PrevPage;
            SetHeadBtnValue();
            $(panContainer).animate({ height: 0 }, 200);
        }
        var NextPanYear = function () {
            if (arrPan.length > 1) return false;
            panYearStartYear += 12;
            MovePanNext(CreatePanYear(panYearStartYear));
            if (panCellArr[yearChanging - panYearStartYear] && panCellArr[yearChanging - panYearStartYear].innerHTML == yearChanging) {
                panCellArr[yearChanging - panYearStartYear].className = "panCellCurr";
            }
            options.event.year.next(caleContainer.caleId);
        }
        var PrevPanYear = function () {
            if (arrPan.length > 1) return false;
            panYearStartYear -= 12;
            MovePanPrev(CreatePanYear(panYearStartYear));
            if (panCellArr[yearChanging - panYearStartYear] && panCellArr[yearChanging - panYearStartYear].innerHTML == yearChanging) {
                panCellArr[yearChanging - panYearStartYear].className = "panCellCurr";
            }
            options.event.year.prev(caleContainer.caleId);
        }

        var NextPanMonth = function () {
            if (arrPan.length > 1) return false;
            yearChanging++;
            MovePanNext(CreatePanMonth());
            options.event.month.next(caleContainer.caleId);
        }
        var PrevPanMonth = function () {
            if (arrPan.length > 1) return false;
            yearChanging--;
            MovePanPrev(CreatePanMonth());
            options.event.month.prev(caleContainer.caleId);
        }

        var SetHeadBtnValue = function () {
            yearHeadBtn.innerHTML = yearChanging + options.global.unit.year;
            monthHeadBtn.innerHTML = monthChanging + options.global.unit.month;
        }

        var MovePanNext = function (panTd) {
            panContainer.style.width = (2 * options.global.size.width) + "px";
            panOuterTableTr.appendChild(panTd);
            $(panContainer).animate({ left: -options.global.size.width }, 200, 0, 0, function (me) {
                panOuterTableTr.removeChild(arrPan.shift())
                panContainer.style.width = options.global.size.width + "px";
                panContainer.style.left = "0px";
            });
        }

        var MovePanPrev = function (panTd) {
            panContainer.style.width = (2 * options.global.size.width) + "px";
            panOuterTableTr.insertBefore(panTd, arrPan[0]);
            panContainer.style.left = -options.global.size.width + "px";
            $(panContainer).animate({ left: 0 }, 200, 0, 0, function (me) {
                panOuterTableTr.removeChild(arrPan.shift())
                panContainer.style.width = options.global.size.width + "px";
            });
        }
        //panContainer


        //Event
        var EventYearHeadClick = function () {
            if (panContainer.style.height == "0px") {
                monthHeadBtn.innerHTML = "";
                if (arrPan.length > 0) {
                    panOuterTableTr.removeChild(arrPan.shift());
                }
                panYearStartYear = (parseInt((yearChanging - yearNow + 4) / 12)) * 12 + yearNow - 4;
                panOuterTableTr.appendChild(CreatePanYear(panYearStartYear));
                if (panCellArr[yearChanging - panYearStartYear] && panCellArr[yearChanging - panYearStartYear].innerHTML == yearChanging) {
                    panCellArr[yearChanging - panYearStartYear].className = "panCellCurr";
                }
                EventNextClick = NextPanYear;
                EventPrevClcik = PrevPanYear;
                $(panContainer).animate({ height: bodyContainer.offsetHeight }, 200);
            }
            else {
                ClosePanContainer();
            }
        }
        var EventMonthHeadClick = function () {
            if (panContainer.style.height == "0px") {
                yearHeadBtn.innerHTML = "";
                if (arrPan.length > 0) {
                    panOuterTableTr.removeChild(arrPan.shift());
                }
                panOuterTableTr.appendChild(CreatePanMonth());
                EventNextClick = NextPanMonth;
                EventPrevClcik = PrevPanMonth;
                $(panContainer).animate({ height: bodyContainer.offsetHeight }, 200);
            }
            else {
                ClosePanContainer();
            }
        }
        var EventNextClick = NextPage;
        var EventPrevClcik = PrevPage;




        //ini
        caleContainer.style.width = options.global.size.width + "px";
        caleContainer.style.height = "auto";
        caleContainer.style.overflow = "hidden";
        CreateHead();
        weekdayContainer.appendChild(CreateWeekday());

        pageOuterTr.appendChild(CreatePage(yearInput[caleContainer.caleId], monthInput[caleContainer.caleId]));

        CreateFoot();
        root.appendChild(caleContainer);
        IniPanContainer();


        bodyContainer.style.height = bodyContainer.offsetHeight + "px";

        this.Input = function (year, month) {
            monthChanging = month;
            yearChanging = year;
            pageOuterTr.removeChild(arrPage[caleContainer.caleId].pop());
            CreatePage(year, month);
            pageOuterTr.appendChild(arrPage[caleContainer.caleId][0]);
            Output(caleContainer.caleId)
        }
    }; //CreateFrame

    var Output = function (caleId) {
        if (outputObj.length != options.global.range.length) {
            for (var i = arrCale.length - 1; i >= 0; i--) {
                if (!arrCale[i].selected) {
                    return false;
                    break;
                }
            }
            if (outputObj[0].tagName != "INPUT")
                outputType = "innerHTML";
            else
                outputType = "value";
            outputObj[0][outputType] = AssembleOutput(dayOutput[0]);
            arrCale[0].selected = false;
            for (var i = 1; i < options.global.range.length; i++) {
                outputObj[0][outputType] += options.global.range.connect + AssembleOutput(dayOutput[caleId]);
                arrCale[i].selected = false;
            }
            needToHide = false;
            if (options.global.autoHide)
                hide();
        }
        else {
            if (outputObj[caleId].tagName != "INPUT")
                outputType = "innerHTML";
            else
                outputType = "value";
            outputObj[caleId][outputType] = AssembleOutput(dayOutput[caleId]);
            var count = 0;
            for (var i = arrCale.length - 1; i >= 0; i--) {
                if (!arrCale[i].selected) {
                    break;
                }
                count++;
            }
            if (count == arrCale.length) {
                needToHide = false;
                if (options.global.autoHide)
                    hide();
            }
        }
        options.event.output({ year: dayOutput[caleId].year, month: dayOutput[caleId].month, day: dayOutput[caleId].day });
    }

    var AssembleOutput = function (o) {
        return o.year + options.global.outputUnit.year + ((o.month > 9) ? o.month : "0" + o.month) + options.global.outputUnit.month + ((o.day > 9) ? o.day : "0" + o.day) + options.global.outputUnit.day + options.global.outputUnit.suffix;
    }



    //method
    var setOutputObj = this.setOutputObj = function (o) {
        o = (typeof (o) === 'string') ? $(o) : o;
        outputObj = this.outputObj = $(o);
    };
    var isLeapYear = this.isLeapYear = function (year) {
        return ((parseInt(year / 4) * 4 == year) && (parseInt(year / 100) * 100 != year)) || (parseInt(year / 400) * 400 == year);
    };
    var getMonthLength = this.getMonthLength = function (year, month) {
        var monthLength = monthMax[month - 1];
        if (month == 2) {
            if (isLeapYear(year)) {
                monthLength = 29;
            }
            else {
                monthLength = 28;
            }
        }
        return monthLength;
    };
    var needToHide = false;
    $(root).addEvent("mouseover", function () {
        needToHide = true;
    }).addEvent("mouseout", function () {
        needToHide = false;
    })
    var show = this.show = function (t) {
        if (root.style.display == "block") {
            return false;
        }
        for (var i = 0; i < arrCale.length; i++) {
            arrCale[i].selected = false;
        }
        if (!obj.options.global.root) {
            $(document.body).addEvent("click", hide, true);
        }
        needToHide = true;
        var pageH = getPageSize().PageH;
        root.style.display = "block";
        if (!options.global.location.follow) {
            t = trigger[options.global.location.index];
        }
        var top = $(t).getTop() + t.offsetHeight;
        root.style.top = top + "px";
        if (pageH < getPageSize().PageH) {
            top = top - root.offsetHeight - t.offsetHeight;
            root.style.top = top + "px";
        }
        
        root.style.left = $(t).getLeft() + "px";
    }
    var hide = this.hide = function () {
        if (!needToHide) {
            root.style.display = "none";
            $(document.body).removeEvent("click", hide);
        }
    }
    this.setTrigger = function (o) {
        trigger = (typeof (o) === 'string') ? $(o) : o;
        trigger.addEvent("click", function (me) {
            obj.show(me);
        }).addEvent("mouseover", function () {
            needToHide = true;
        }).addEvent("mouseout", function () {
            needToHide = false;
        });
    }
    this.ini = function () {
        if (obj.options.global.root) {
            document.body.removeChild(root);
            root = obj.options.global.root;
            this.root = root;
            root.className += " CaleRoot";
            options.global.autoHide = false;
        }

        for (var i = 0; i < options.global.range.length; i++)
            this.calendar[i] = new CreateFrame();
        if (!obj.options.global.root) {
            root.style.width = options.global.range.length * arrCale[0].offsetWidth + "px";
            root.style.display = "none";
            root.style.position = "absolute";
        }
    }
    this.input = function (arrInput) {
        for (var i = 0; i < options.global.range.length; i++) {
            var t = arrInput[i].match(/[0-9]{1,4}/g);
            yearInput[i] = parseInt(t[0]);
            yearOutput[i] = parseInt(t[0]);
            monthInput[i] = parseInt(t[1]);
            monthOutput[i] = parseInt(t[1]);
            dayInput[i] = parseInt(t[2]);
            obj.calendar[i].Input(yearInput[i], monthInput[i])
        }
    }
    //method
}
//Supx Presents
